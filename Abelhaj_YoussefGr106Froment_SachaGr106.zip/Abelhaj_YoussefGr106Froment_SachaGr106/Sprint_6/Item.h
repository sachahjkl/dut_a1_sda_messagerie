#ifndef _ITEM_
#define _ITEM_

/**
* @file Item.h
* Projet Sprint 6
* @author Abelhaj Youssef et Froment Sacha G106
* @version 1 - 14/12/2017
* @brief Sp�cialisation du type Item
* Structures de donn�es et algorithmes - DUT1 Paris 5
*/

#include "MessageEnCours.h"

typedef MessageEnCours Item;

#endif
